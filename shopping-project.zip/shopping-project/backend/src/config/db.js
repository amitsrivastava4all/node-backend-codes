import mongoose from 'mongoose';
export const createConnection = async ()=>{
    try{
    const URL = process.env.MONGO_URL;
    if(!URL){
        throw new Error('DB URL is Missing...');
    }
    const dbOptions = {
        connectTimeoutMS: 10000,
        maxPoolSize: 10, 
        useNewUrlParser: true,
        useUnifiedTopology:true,
        autoIndex:process.env.NODE_ENV!=='PROD'
    }
    return await mongoose.connect(URL, dbOptions);
}
catch(err){
    throw err;
}
}