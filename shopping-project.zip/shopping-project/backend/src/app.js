import express from 'express';
import cors from 'cors';
import compression from 'compression';
import helmet from 'helmet';
const createApp = ()=>{
    const app = express();
    app.use(cors());
    app.use(express.json({limit:'10mb'}));
    app.use(express.urlencoded({extended:true, limit:'10mb'}));
    app.use(helmet());
    app.use(compression());
    return app;

}
export default createApp;