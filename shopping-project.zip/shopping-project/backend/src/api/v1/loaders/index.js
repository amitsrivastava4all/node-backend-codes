import { logger } from "../../../utils/logger/color-logger.js"
import { expressLoader } from "./express-loader.js";
import { mongooseLoader } from "./mongoose-loader.js";

// all loaders will be call here
export const initApp = async ()=>{
    try{
    logger.info('App Start');
    const dbConnection = await mongooseLoader();
    logger.db(`Database Connection Created ${dbConnection}` );
    // start the express
    const app = expressLoader();
    logger.success('Express App Init ...');
    const server= app.listen(process.env.PORT || 5000, ()=>{
        logger.success('App Up and Running ');
    });
    const shutDown = ()=>{
        if(server){
            server.close();
        }
        if(dbConnection.readyState){
            dbConnection.close();
        }
    }
    return {app, server, dbConnection, shutDown};
}
catch(err){
    logger.error('Index Loader Fails.. ', err);
    throw err;
}

}

