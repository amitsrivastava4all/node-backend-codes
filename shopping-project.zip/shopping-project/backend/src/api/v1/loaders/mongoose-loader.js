import mongoose from "mongoose";
import { logger } from "../../../utils/logger/color-logger.js";
import { createConnection } from "../../../config/db.js";

// mongoose events
const setUpEvents = ()=>{
    mongoose.connection.on('error',err=>{
        // log it
        logger.error(err);
    });
    mongoose.connection.on('disconnected', err=>{
        logger.db('DB is Down ');
    });
    process.on('SIGINT', async ()=>{
        await mongoose.connection.close();
        // log
        logger.info('Graceful Shutdown ');
        process.exit(0);
    })
}
export const mongooseLoader = async ()=>{
    try{
    const connection = await createConnection();
    logger.db('DB Connection Created....');
    setUpEvents();
    return connection;
    // log
    }
    catch(err){
        // log it
        logger.error('DB Connection Fails');
        throw err;
    }
}