import HttpError from "http-errors";
import createApp from "../../../app.js";
import { logger } from "../../../utils/logger/color-logger.js";
const {createError} = HttpError; 
export const expressLoader = ()=>{
    try{
    const app = createApp();
    // own middleware
    app.use((request, response, next)=>{
        // log the request
        logger.http(`${request.method} ${request.originalUrl}`);
        const startTime = Date.now();
        response.on('finish', ()=>{
            const duration = Date.now() - startTime;
            logger.http(`${request.method} ${request.originalUrl} Time ${duration}`);
        });
        next();
    });

    // Checking Route Health
    app.get('/health', (request, response)=>{
        response.status(200).json({status:'OK', message:'API Up and Running'});
    });

    //app.use('/api/v1',apiRoutes);
    // 404 Error
    app.use((request, response, next)=>{
        next(createError(404, `This Route ${request.originalUrl} is not present`)); // There would be some error handler
    });
    // Generic Error Handler
    app.use((err, request, response, next)=>{
        const statusCode = err.status || 500 ;
        const message = err.message  || 'Internal Server Error';
        logger.error(`${statusCode} ${message} ${request.method} ${request.originalUrl} ${request.ip}`);
        const error = process.env.NODE_ENV ==='DEV'?{'message':err.message,'stack': err.stack}:{'message':err.message};
        response.status(statusCode).json({error, success:false});
    })
    return app;
}
catch(err){
    throw err;
}
    
}