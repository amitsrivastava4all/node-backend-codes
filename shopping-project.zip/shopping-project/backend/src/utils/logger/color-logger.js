import chalk from 'chalk';
export const logger = {
    info:(message)=>{
        console.log(`${chalk.blue('INFO')}> ${message}`);
    },
    success:(message)=>{
        console.log(`${chalk.green('SUCCESS')}> ${message}`);
    },
     warn:(message)=>{
        console.log(`${chalk.yellow('SUCCESS')}> ${message}`);
    },
     error:(message)=>{
        console.log(`${chalk.red('ERROR')}> ${message}`);
    },
     db:(message)=>{
        console.log(`${chalk.bgMagentaBright('DB')}> ${message}`);
    },
     http:(message, statusCode)=>{
        const statusColor = statusCode>=500?chalk.red:
        statusCode>=400?chalk.yellow:
        statusCode>=300?chalk.blueBright:
        statusCode>=200?chalk.greenBright:chalk.grey;
        console.log(`${statusColor('HTTP')}> ${message} ${statusCode}`);
    }
}