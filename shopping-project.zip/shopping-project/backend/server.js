
import { initApp } from './src/api/v1/loaders/index.js';
import { logger } from './src/utils/logger/color-logger.js';
import dotenv from 'dotenv';
dotenv.config();
const startServer = async ()=>{
   
    const {app, server, dbConnection, shutDown} = await initApp();
    console.log('ShutDown ', typeof shutDown, shutDown);
    process.on('SIGINT', ()=>{
        shutDown();
    });
    process.on('uncaughtException', err=>{
        logger.error('Something Went Wrong '+err);
        shutDown();
    })
}
startServer();
