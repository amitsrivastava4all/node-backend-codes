import express from 'express';
export const homeRoutes = express.Router();
homeRoutes.get('/home', (request, response)=>{
    response.send("<h1>Hello Express</h1>");
});