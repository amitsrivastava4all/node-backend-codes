import express from 'express';
export const userRoutes = express.Router();
userRoutes.post('/register', (request, response)=>{
    const userInfo = request.body; // JSON
    response.status(200).json(userInfo);
});

userRoutes.post('/login', (request, response)=>{
    const userInfo = request.body;
    console.log('User Info is ', userInfo);
    if(userInfo.userid == userInfo.pwd){
        response.send("<h2>Welcome "+userInfo.userid+"</h2>");
    }
    else{
        response.send("<h2>Invalid Userid or password</h2>");
    }
    
})
