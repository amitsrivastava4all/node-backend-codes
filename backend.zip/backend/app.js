import express from 'express';
import dotenv from 'dotenv';
import chalk from 'chalk';
import { homeRoutes } from './api/v1/routes/home-routes.js';
import { userRoutes } from './api/v1/routes/user-routes.js';
dotenv.config(); 
const app = express();
// /
//app.use(middleware);
app.use(express.static('public')); // prebuild middleware

app.use(express.urlencoded()); // userid=amit&pwd=123

app.use(express.json());

// Modular Routes
app.use('/',homeRoutes);
app.use('/',userRoutes);

const server = app.listen(process.env.PORT || 9999, err=>{
    if(err){
        console.log(chalk.redBright.bold('App Crash '), err);
    }
    else{
        console.log(chalk.greenBright.bold('App Up and Running '), server.address().port);
    }
})