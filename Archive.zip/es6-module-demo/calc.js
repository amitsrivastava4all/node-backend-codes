function add(x,y){
    return x + y;
}
export function subtract(x,y){
    return x - y;
}
export default add;
