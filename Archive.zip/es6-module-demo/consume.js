import adder, {subtract} from './calc.js';
console.log(adder(10,20));
console.log(subtract(100,20));