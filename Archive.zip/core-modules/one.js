import os from 'os'; // Core Module
import chalk from 'chalk';
import figlet from 'figlet';

figlet('Hello Node', function(err, content){
    if(err){
        console.log(chalk.red.bold('Something Went Wrong...'));
    }
    else{
        console.log(chalk.yellow(content));
    }
})
console.log(chalk.green.bold.underline('Hello Chalk'));
console.log(os.arch());
console.log(os.platform());
console.log(os.cpus().length);
console.log(os.freemem());
console.log(os.version());
console.log(os.hostname());