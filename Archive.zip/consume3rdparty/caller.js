import {add, subtract} from 'brainmentors_math';
console.log(add(10,20));
console.log(subtract(1000,200));