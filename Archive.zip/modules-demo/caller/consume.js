const obj = require('../math');
console.log('require ', typeof require);
console.log(obj);
console.log(obj.add(10,20));
console.log(obj.subtract(100,200));