const r = require('./index');
console.log(r.add(10,20));
console.log(r.subtract(100,200));