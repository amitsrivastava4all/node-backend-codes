
function add(x,y){
    return x + y;
}
function subtract(x,y){
    return x - y;
}
console.log('Module ', typeof module);
console.log('Exports ', typeof module.exports, ' ', module.exports);
module.exports = {add, subtract}; // ShortHand Style
//module.exports = {add:function(x,y){}, subtract:function(x,y){}}
// JS Objects Literal {key:value}