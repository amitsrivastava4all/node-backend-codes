import { connectDB } from './src/config/db.js';
import app from './src/app.js';
import chalk from 'chalk';


const PORT = process.env.PORT || 5000;
const promise = connectDB();
promise.then(()=>{
    app.listen(PORT, () => {
        console.log(chalk.greenBright.bold(`🚀 Server running on http://localhost:${PORT}`));
      });
}).catch(err=>{
    console.log(chalk.redBright.bold('DB Not Up and Running....'), err);
})
