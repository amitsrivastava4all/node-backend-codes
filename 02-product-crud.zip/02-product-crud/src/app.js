import express from 'express';
import dotenv from 'dotenv';
import morgan from 'morgan';
import v1Routes from './api/v1/index.js';

dotenv.config();
const app = express();

// here we consume the middleware
// app.use(middleware)
app.use(express.json());
app.use(morgan('dev'));
app.use('/api/v1', v1Routes); // prefix the version of api 

export default app;