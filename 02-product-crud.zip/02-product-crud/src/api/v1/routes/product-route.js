import express from 'express';
import * as controller from '../controllers/product-controller.js';
import { validateProduct } from '../../../utils/validations/product-validation.js';

const router = express.Router();
// post, get , put, delete - HTTP METHODS
// post - create operation
router.post('/', validateProduct, controller.createProduct);
// get - read operation
router.get('/', controller.getAllProducts);
// get - read with filter
router.get('/:id', controller.getProductById);
// put - update operation
router.put('/:id', validateProduct, controller.updateProduct);
// delete - delete operation
router.delete('/:id', controller.deleteProduct);

export default router;