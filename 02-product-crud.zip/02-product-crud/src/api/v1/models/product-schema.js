import mongoose from 'mongoose';

const productSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Product name is required'],
    minlength: [3, 'Minimum 3 characters required'],
    trim: true
  },
  price: {
    type: Number,
    required: true,
    min: [1, 'Price must be at least 1']
  },
  qty: {
    type: Number,
    required: true,
    min: [0, 'Quantity cannot be negative']
  },
  description: {
    type: String,
    required: true,
    maxlength: 300
  }
}, { timestamps: true });

export const Product = mongoose.model('products', productSchema);