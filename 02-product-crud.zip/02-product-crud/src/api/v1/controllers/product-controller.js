import * as productService from '../services/product-service.js';

export const createProduct = async (req, res) => {
  const result = await productService.create(req.body);
  res.status(201).json(result);
};

export const getAllProducts = async (req, res) => {
  const result = await productService.getAll();
  res.status(200).json(result);
};

export const getProductById = async (req, res) => {
  const result = await productService.getById(req.params.id);
  if (!result) return res.status(404).json({ error: "Not found" });
  res.status(200).json(result);
};

export const updateProduct = async (req, res) => {
  const result = await productService.update(req.params.id, req.body);
  console.log('result of update is ', result);
  res.status(200).json(result);
};

export const deleteProduct = async (req, res) => {
  await productService.remove(req.params.id);
  res.status(204).send();
};