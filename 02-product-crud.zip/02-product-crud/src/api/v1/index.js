import express from 'express';
import productRoutes from './routes/product-route.js';

const router = express.Router();
router.use('/products', productRoutes);
// all routes path maintain here for api version1 
export default router;