import Joi from 'joi';
// npm i joi
// this is the schema of product validation
export const productValidationSchema = Joi.object({
  name: Joi.string().min(3).required(),
  price: Joi.number().min(1).required(),
  qty: Joi.number().min(0).required(),
  description: Joi.string().max(300).required()
});

// this is a middleware
// middleware - it is just a function
// having three arguments - request , response , next (next middleware call)
export const validateProduct = (req, res, next) => {
  const { error } = productValidationSchema.validate(req.body);
  if (error) {
    return res.status(400).json({ error: error.details[0].message });
  }
  next();
};