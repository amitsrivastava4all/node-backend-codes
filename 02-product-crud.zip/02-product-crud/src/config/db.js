import mongoose from 'mongoose';
// process.env.DB_URL 
export const connectDB = async () => {
  try {
    const conn = await mongoose.connect(process.env.DB_URL);
    console.log(`MongoDB Connected: ${conn.connection.host}`);
    return conn;
  } catch (error) {
    console.error(`DB Error: ${error.message}`);
    process.exit(1);
  }
};