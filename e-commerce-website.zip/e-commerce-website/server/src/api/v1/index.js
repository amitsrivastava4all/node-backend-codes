// src/api/v1/routes/index.js

import express from 'express';
import productRoutes from './routes/product-routes.js';

const router = express.Router();

// Product routes
router.use('/products', productRoutes);

export default router;