// src/App.tsx

import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Toaster } from 'sonner';
import { HomePage } from './modules/home/pages/HomePage';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<HomePage />} />
        {/* Add other routes here when implementing them */}
        <Route path="*" element={<div>Page not found</div>} />
      </Routes>
      <Toaster position="top-center" />
    </BrowserRouter>
  );
}

export default App;