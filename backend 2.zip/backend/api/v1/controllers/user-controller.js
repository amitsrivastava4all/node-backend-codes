import { addUser, getUser } from "../services/user-service.js";
import { generateToken } from "../utils/token.js";

export const login = async (request, response)=>{
    const userInfo = request.body;
    const isLoggedIn =  await getUser(userInfo);
    if(isLoggedIn){
        const token = generateToken(userInfo.email);
        response.status(200).json({message:'Login SuccessFully ', email:userInfo.email, token : token});
    }
    else{
        response.status(404).json({message:'Invalid Email or Password'});
    }


    // console.log('User Info is ', userInfo);
    // if(userInfo.userid == userInfo.pwd){
    //     response.send("<h2>Welcome "+userInfo.userid+"</h2>");
    // }
    // else{
    //     response.send("<h2>Invalid Userid or password</h2>");
    // }
    
}

export const register = async (request, response)=>{
    const userInfo = request.body; // JSON
    console.log('****User Info is ', userInfo);
    try{
    const doc = await addUser(userInfo);
    response.status(200).json({message:'User Register SuccessFully', email:doc.email});
    }
    catch(err){
        response.status(500).json({message:'Problem in User Register'});
        console.log(err);
    }
    response.status(200).json(userInfo);
}