export const search = (request, response)=>{
    //const query = request.query;
    const pathParam  = request.params;
    console.log('Path  is ', pathParam.q);
    response.send('Product Search Query '+pathParam.q + " "+pathParam.price);
}