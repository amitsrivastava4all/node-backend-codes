export const home= (request, response)=>{
    response.send("<h1>Hello Express</h1>");
}