export function getOrders(request, response){
    response.status(200).json({orders:[{id:1001, name:'OrderA'}, {id:1002, name:'OrderB'}]});
}