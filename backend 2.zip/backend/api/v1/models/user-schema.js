import mongoose, {Schema} from "mongoose";
const UserSchema = new Schema({
    email: {type:Schema.Types.String, maxLength:100, required:true, unique:true},
    password: {type:Schema.Types.String, minLength:8, required:true},
    name:{type:Schema.Types.String, minLength : 3, required:true}

});
export const UserModel = mongoose.model('users', UserSchema);

