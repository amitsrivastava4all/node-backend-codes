import { verifyToken } from "./token.js";

export const tokenVerify = (request, response, next)=>{
    const token =request.headers['authorization'];
    console.log('Token is in Header ', token);
    try{
    const obj = verifyToken(token);
    if(obj && obj.email){
        next();
    }
    else{
        response.status(401).json({message:'UnAuthorized Access Token Not Verified'});
    }
    }
    catch(err){
        //console.log('Invalid Token ', err);
        response.status(401).json({message:'UnAuthorized Access Token Not Verified'});
    }
    
    

}