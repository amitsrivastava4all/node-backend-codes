import jwt from 'jsonwebtoken';
export function generateToken(email){
    const token = jwt.sign({email:email},process.env.JWT_SECRET_KEY,{
        expiresIn:process.env.JWT_ACCESS_TOKEN_EXPIRY
    });
    return token;
}

export function verifyToken(token){
    const obj = jwt.verify(token, process.env.JWT_SECRET_KEY);
    return obj;
}
