import bcrypt from 'bcrypt';
export function generateHash(plainPwd){
   return bcrypt.hashSync(plainPwd,10);
}

export function compareHash(plainPwd, dbHashPwd){
    return bcrypt.compareSync(plainPwd, dbHashPwd);
}