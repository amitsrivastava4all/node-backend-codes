import express from 'express';
import { home } from '../controllers/home-controller.js';
export const homeRoutes = express.Router();
homeRoutes.get('/home', home);
