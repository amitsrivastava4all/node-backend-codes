import express from 'express';
import { search } from '../controllers/product-controller.js';
export const productRoutes = express.Router();
productRoutes.get('/search/:q/:price',search);