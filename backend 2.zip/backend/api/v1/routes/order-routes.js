import express from 'express';
import { getOrders } from '../controllers/order-controller.js';
import { tokenVerify } from '../utils/token-middleware.js';
export const orderRoutes = express.Router();
orderRoutes.get('/get-orders',tokenVerify ,getOrders);