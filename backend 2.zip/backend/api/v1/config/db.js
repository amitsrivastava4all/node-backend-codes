import mongoose from 'mongoose';
// const promise = mongoose.connect(process.env.DB_URL, {
//     maxPoolSize : 5
// });
// promise.then(()=>{
//     console.log('DB Connected ....')
// }).catch(err=>{
//     console.log('DB Connection Error...');
// })
export function connectToDB(){
    return mongoose.connect(process.env.DB_URL, {
            maxPoolSize : 5
            
        });    
}