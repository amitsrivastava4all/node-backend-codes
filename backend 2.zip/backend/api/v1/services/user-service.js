import { UserModel } from "../models/user-schema.js";
import { compareHash, generateHash } from "../utils/encrypt.js";

// DB CRUD Operations
export async function addUser(userObject){
   userObject.password = generateHash(userObject.password);
   return await  UserModel.create(userObject);
}

export async function getUser(userObject){
   const doc = await UserModel.findOne({email:userObject.email}).exec();
   if(doc && doc.email){
      if(compareHash(userObject.password , doc.password)){
         return true;
      }
   }
   return false;
}
