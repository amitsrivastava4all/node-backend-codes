import { createLogger, transports, format } from 'winston';

export const logger = createLogger({
  level: 'debug',
  format: format.combine(
    format.label({label:'Brain Mentors Website'}),
    format.timestamp(),
    format.errors({ stack: true }),
    format.splat(),
    format.json()
  ),
  transports: [
    new transports.File({ filename: 'logs/error.log', level: 'error' ,maxFiles:10, maxsize:5*1024*1024}),
    new transports.File({ filename: 'logs/combined.log' }),
    new transports.Console({ format: format.simple() })
  ],
});