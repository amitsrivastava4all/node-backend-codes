export const authorize = ({ type, page, action }) => (req,res,next) => {
    const perms = req.user.permissions || [];
    const ok = perms.some(p =>
      p.type===type &&
      (p.page===page || p.page==='all') &&
      (p.action===action || p.action==='manage')
    );
    if (!ok) return res.status(403).json({ message: 'Forbidden' });
    next();
  };