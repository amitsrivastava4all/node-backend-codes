import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';

const permSchema = new mongoose.Schema({
  object_type:   String,   // e.g. "user", "product", from which collection it linked
  name:   String,   // e.g. what task it  does in english (like Add Page, Browse Product, Add Product)
  action_type: String    // e.g. "read", "edit", "manage"
}, { _id: false });

const userSchema = new mongoose.Schema({
  name:        { type: String, required: true, trim: true },
  email:       { type: String, required: true, unique: true, lowercase: true },
  password:    { type: String, required: true, minlength: 6 },
  role:        { type: String, enum: ['admin','moderator','user'], default: 'user' },
  permissions: [permSchema],

  resetToken:   String,
  resetExpires: Date,

  refreshToken: String
}, { timestamps: true });

// Hash password
userSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 12);
  next();
});

// Compare
userSchema.methods.matchPassword = function(plainPwd) {
  return bcrypt.compare(plainPwd, this.password);
};

export const User = mongoose.model('users', userSchema);