import * as authService from '../services/auth-service.js';
import {logger} from '../../../utils/loggers/app-logger.js';


export const registerUser = async (req, res, next) => {
  try {
    logger.debug('I am in Register User Controller ', req.body);
    const user = await authService.register(req.body);
    res.status(201).json({ message: 'User registered', user });
  } catch (err) {
    logger.error('Error in Register User ', err);
    next(err);
  }
};

export const loginUser = async (req, res, next) => {
  try {
    const { user, accessToken, refreshToken } = await authService.login(req.body);
    // send refresh token as httpOnly cookie
    res.cookie('refreshToken', refreshToken, {
      httpOnly: true,
      secure: true,
      sameSite: 'strict',
      maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
    });
    res.json({ message: 'Login successful', user, accessToken });
  } catch (err) {
    next(err);
  }
};

export const refreshToken = async (req, res, next) => {
  try {
    const oldToken = req.cookies.refreshToken;
    if (!oldToken) return res.status(401).json({ message: 'No refresh token' });

    const { accessToken, refreshToken } = await authService.refreshTokens(oldToken);
    // overwrite cookie
    res.cookie('refreshToken', refreshToken, {
      httpOnly: true,
      secure: true,
      sameSite: 'strict',
      maxAge: 7 * 24 * 60 * 60 * 1000,
    });
    res.json({ message: 'Token refreshed', accessToken });
  } catch (err) {
    next(err);
  }
};

export const logoutUser = (req, res, next) => {
  try {
    res.clearCookie('refreshToken', {
      httpOnly: true,
      secure: true,
      sameSite: 'strict',
    });
    res.json({ message: 'Logged out' });
  } catch (err) {
    next(err);
  }
};

export const forgotPassword = async (req, res, next) => {
  try {
    await authService.forgotPassword(req.body.email); // // Email 
    res.json({ message: 'Password reset link sent to email' });
  } catch (err) {
    next(err);
  }
};

export const resetPassword = async (req, res, next) => {
  try {
    await authService.resetPassword(req.body); 
    res.json({ message: 'Password has been reset' });
  } catch (err) {
    next(err);
  }
};

