import crypto from 'crypto';
import jwt from 'jsonwebtoken';
import { User } from '../models/user-model.js';
import { transporter } from '../../../config/email.js';

import { signAccessToken, signRefreshToken } from '../../../utils/token.js';

import { promises as fs } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname  = dirname(__filename);

// Load permissions.json
const permissionsPath = join(__dirname, '../models/permission.json');
const permissionsMap  = JSON.parse(
  await fs.readFile(permissionsPath, 'utf8')
);

export const register = async ({ name, email, password }) => {
  const user = await User.create({
    name, email, password,
    permissions: permissionsMap['user']
  });
  return user;
};

export const login = async ({ email, password }) => {
  const user = await User.findOne({ email });
  if (!user || !(await user.matchPassword(password)))
    throw new Error('Invalid credentials');

  const payload = { id: user._id, role: user.role };
  const accessToken  = signAccessToken(payload);
  const refreshToken = signRefreshToken(payload);

  user.refreshToken = refreshToken; // DB Store because expiry it is big
  await user.save();
  return { user, accessToken, refreshToken };
};

export const refreshTokens = async (oldToken) => {
  const decoded = jwt.verify(oldToken, process.env.JWT_REFRESH_SECRET);
  const user = await User.findById(decoded.id);
  if (!user || user.refreshToken !== oldToken)
    throw new Error('Invalid refresh token');

  const newAccess  = signAccessToken({ id: user._id, role: user.role });
  const newRefresh = signRefreshToken({ id: user._id, role: user.role });

  user.refreshToken = newRefresh;
  await user.save();
  return { accessToken: newAccess, refreshToken: newRefresh };
};

export const forgotPassword = async (email) => {
  const user = await User.findOne({ email });
  if (!user) throw new Error('No user found');
  // Generate a Token and save it in db with expiry time
  const token = crypto.randomBytes(20).toString('hex');
  user.resetToken   = token;
  user.resetExpires = Date.now() + 60 * 60 * 1000; // 1hr
  await user.save();
  // Create a URL 
  const url = `${process.env.CLIENT_URL}/reset-password?token=${token}`;
  await transporter.sendMail({
    to: email,
    subject: 'Password Reset',
    html: `<p>Reset via <a href="${url}">this link</a></p>`
  });
};

export const resetPassword = async ({ token, password }) => {
  const user = await User.findOne({
    resetToken:   token,
    resetExpires:{ $gt: Date.now() }
  });
  if (!user) throw new Error('Invalid/expired token');

  user.password    = password;
  user.resetToken  = undefined;
  user.resetExpires= undefined;
  await user.save();
};