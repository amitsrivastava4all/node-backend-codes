import express from 'express';
import userRoutes from './routes/auth-route.js';

const router = express.Router();
router.use('/users', userRoutes);
// all routes path maintain here for api version1 
export default router;