import express from 'express';
import cookieParser from 'cookie-parser';
import { validate } from '../../../utils/middlewares/validation.js';
import {
  registerSchema, loginSchema, emailSchema, resetSchema
} from '../../../utils/middlewares/auth-validation.js';
import * as ctrl from '../controllers/auth-controller.js';

const router = express.Router();
router.use(cookieParser());

router.post('/register',validate(registerSchema), ctrl.registerUser);
router.post('/login',validate(loginSchema),    ctrl.loginUser);
router.post('/refresh',ctrl.refreshToken);
router.post('/logout',ctrl.logoutUser);
router.post('/forgot-password',validate(emailSchema),    ctrl.forgotPassword);
router.post('/reset-password', validate(resetSchema),   ctrl.resetPassword);

export default router;