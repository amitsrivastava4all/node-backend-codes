import mongoose from 'mongoose';
import { logger } from '../utils/loggers/app-logger.js';

export const connectDB = async () => {
  try {
    await mongoose.connect(process.env.DB_URL,{maxPoolSize:10});
    logger.debug('DB Connected...');
    logger.info('✅ MongoDB connected SuccessFully');
  } catch (err) {
    logger.error('❌ DB Connection Failed: %s', err.message);
    process.exit(1);
  }
};