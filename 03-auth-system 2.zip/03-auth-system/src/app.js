// src/app.js
import express from 'express';
import dotenv from 'dotenv';
import helmet from 'helmet';
import cors from 'cors';
import rateLimit from 'express-rate-limit';
import mongoSanitize from 'express-mongo-sanitize';
import xssClean from 'xss-clean';
import csurf from 'csurf';
import morgan from 'morgan';
import cookieParser from 'cookie-parser';

import { logger } from './utils/loggers/app-logger.js';
import apiV1 from './api/v1/index.js';

// Register Event 
process.on('uncaughtException', (err)=>{
  console.log('Something went Wrong... ', err);
})

dotenv.config();
const app = express();

// 1) PARSE JSON + COOKIES
app.use(express.json());
app.use(cookieParser());

app.use(
  morgan('combined', {
    stream: { write: msg => {
      
      logger.info(msg.trim()) ;
    }
  }
  })
);

// 2) SECURITY MIDDLEWARE
app.use(helmet());
app.use(cors());
// app.use(
//   cors({
//     origin: process.env.CLIENT_URL,
//     credentials: true
//   })
// );
app.use(rateLimit({ windowMs: 15 * 60 * 1000, max: 100 }));

// 3) INPUT SANITIZATION

// Make req.query and req.params into normal, mutable objects
app.use((req, _res, next) => {
    // Clone the existing values
    const q = req.query   || {};
    const p = req.params  || {};
  
    // Override req.query
    Object.defineProperty(req, 'query', {
      value:     { ...q },
      writable:  true,
      enumerable:true,
      configurable:true
    });
  
    // Override req.params (if you also want to sanitize params)
    Object.defineProperty(req, 'params', {
      value:     { ...p },
      writable:  true,
      enumerable:true,
      configurable:true
    });
  
    next();
  });
  
  // Now it’s safe to sanitize

app.use(mongoSanitize());
app.use(xssClean());

// 4) CSRF PROTECTION (single middleware)
//    - Applies to all non-GET methods by default
//    - Stores token in cookie “XSRF-TOKEN” (httpOnly: false so client/ Postman can read it)
// app.use(
//   csurf({
//     cookie: {
//       key: 'XSRF-TOKEN',
//       httpOnly: false,
//       sameSite: 'strict',
//       secure: process.env.NODE_ENV === 'production'
//     },
//     value: req => req.headers['x-csrf-token']  // look for header on unsafe requests
//   })
// );

// 5) ISSUE CSRF TOKEN FOR CLIENT TO CONSUME
//    This GET is *allowed* (csurf ignores GET), and req.csrfToken() is now available.
// app.get('/csrf-token', (req, res) => {
//   const token = req.csrfToken();
//   // Set cookie for automated clients (Postman/browser)
//   res.cookie('XSRF-TOKEN', token, {
//     httpOnly: false,
//     sameSite: 'strict',
//     secure: process.env.NODE_ENV === 'production'
//   });
//   // Also return in JSON
//   res.json({ csrfToken: token });
// });

// 6) LOGGING


// 7) YOUR API (all POST/PUT/DELETE here are now CSRF-protected)
app.use('/api/v1', apiV1);

// 8) CSRF ERROR HANDLER
// Custom Middlewares (Developer define middlewares)
// app.use((err, req, res, next) => {
//   if (err.code === 'EBADCSRFTOKEN') {
//     return res.status(403).json({ message: 'Invalid CSRF token' });
//   }
//   next(err);
// });

// Custom Middlewares (Developer define middlewares)
app.use((err, req, res, next) => {
 
    return res.status(500).json({ message: 'Something went wrong...' });
  
  
});

app.use((req, res)=>{
  res.status(404).json({message:"404 Error"});
})

export default app;