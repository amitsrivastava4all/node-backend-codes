import app from './src/app.js';
import { connectDB } from './src/config/db.js';
const PORT = process.env.PORT||5000;
const promise = connectDB();
promise.then(()=>{
    app.listen(PORT,()=>console.log(`🚀 Listening on :${PORT}`));
}).catch(err=>{
    console.log('DB Connection Fails... ', err);
})
