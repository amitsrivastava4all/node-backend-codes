// Call AI Model for Predications

import axios from "axios";
import ora from 'ora';
import chalk from 'chalk';
// API Call
export async function getPredications(singleDigit){
   
    const URL = 'https://api-inference.huggingface.co/models/mistralai/Mistral-7B-Instruct-v0.2';
    const prompt = `Act as a 10 year experience Numerology Person
    tell me the destiny of this number ${singleDigit}
    tell me the nature of this number and life path of this number
    `;
    console.log('Prompt is ', prompt);
    try{
        const spinner = ora('Loading....');
        spinner.info();
    const response = await axios.post(URL,{
        inputs:prompt,
    },{
        headers:{
            'Authorization' :'Bearer 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',
            'Content-Type' :'application/json'

        }
       
    });    
    spinner.stop();
    console.log(chalk.green.bold(response.data[0].generated_text));
}
catch(err){
    console.log('Error ::::::::: ' ,err);
}
}